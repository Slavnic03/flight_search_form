const cities = [
  "Beograd", "Njujork", "London", "Pariz", "Dubai", "Tokio", 
  "Sidnej", "Los Anđeles", "Berlin", "Madrid", "Rim", "Moskva"
];

// Definišemo letove za svaki grad
const flightData = {
  "Beograd": [
    { id: 1, airline: "Air Serbia", time: "10:00", price: "120€" },
    { id: 2, airline: "Lufthansa", time: "15:00", price: "150€" }
  ],
  "Njujork": [
    { id: 1, airline: "Delta Airlines", time: "09:00", price: "400€" },
    { id: 2, airline: "United Airlines", time: "18:00", price: "450€" }
  ],
  "London": [
    { id: 1, airline: "British Airways", time: "11:00", price: "200€" },
    { id: 2, airline: "Ryanair", time: "20:00", price: "80€" }
  ],
  // Dodajte slične podatke za ostale gradove...
};

// Dodavanje predloga gradova
document.getElementById("from").addEventListener("input", function () {
  showSuggestions("from", cities);
});

document.getElementById("to").addEventListener("input", function () {
  showSuggestions("to", cities);
});

function showSuggestions(inputId, cityList) {
  const input = document.getElementById(inputId);
  const suggestionsList = document.getElementById(`${inputId}-suggestions`);
  const query = input.value.toLowerCase();

  // Očistimo prethodne sugestije
  suggestionsList.innerHTML = "";

  if (query) {
    cityList
      .filter((city) => city.toLowerCase().startsWith(query))
      .forEach((city) => {
        const listItem = document.createElement("li");
        listItem.textContent = city;
        listItem.addEventListener("click", function () {
          input.value = city;
          suggestionsList.innerHTML = "";
        });
        suggestionsList.appendChild(listItem);
      });
  }
}

// Prikaz rezultata pretrage
document.getElementById("flight-search-form").addEventListener("submit", function (event) {
  event.preventDefault();

  const from = document.getElementById("from").value;
  const to = document.getElementById("to").value;
  const date = document.getElementById("date").value;

  const resultsContainer = document.getElementById("search-results");

  // Očistimo prethodne rezultate
  resultsContainer.innerHTML = "";

  if (from && to && date && flightData[from]) {
    const flights = flightData[from];

    const resultsList = document.createElement("ul");

    flights.forEach((flight) => {
      const listItem = document.createElement("li");
      listItem.textContent = `${flight.airline} - ${flight.time} - ${flight.price}`;
      const bookButton = document.createElement("button");
      bookButton.textContent = "Rezerviši";
      bookButton.classList.add("book-btn");
      bookButton.addEventListener("click", function () {
        bookFlight(from, to, date, flight);
      });
      listItem.appendChild(bookButton);
      resultsList.appendChild(listItem);
    });

    resultsContainer.appendChild(resultsList);
  } else {
    resultsContainer.textContent = "Nema dostupnih letova za odabrane parametre.";
  }
});

// Dodavanje rezervisanog leta
function bookFlight(from, to, date, flight) {
  const bookingsList = document.getElementById("bookings-list");

  const bookingItem = document.createElement("li");
  bookingItem.textContent = `Polazak: ${from}, Dolazak: ${to}, Datum: ${date}, Avio-kompanija: ${flight.airline}, Vreme: ${flight.time}, Cena: ${flight.price}`;

  // Dugme za brisanje
  const deleteButton = document.createElement("button");
  deleteButton.textContent = "Obriši";
  deleteButton.classList.add("delete-btn");
  deleteButton.addEventListener("click", function () {
    bookingItem.remove();
  });

  bookingItem.appendChild(deleteButton);
  bookingsList.appendChild(bookingItem);
}
